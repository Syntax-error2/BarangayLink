<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable {
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
    protected $fillable = ['first_name', 'last_name', 'email', 'password', 'phone', 'role_id', 'barangay_id', 'is_active', 'profile_photo_path'];
    protected $hidden = ['password', 'remember_token'];
    protected $casts = ['email_verified_at' => 'datetime', 'password' => 'hashed', 'is_active' => 'boolean'];
    
    public function role() { return $this->belongsTo(Role::class); }
    public function barangay() { return $this->belongsTo(Barangay::class); }
    public function residentProfile() { return $this->hasOne(ResidentProfile::class); }
    public function staffProfile() { return $this->hasOne(StaffProfile::class); }
    public function responderProfile() { return $this->hasOne(ResponderProfile::class); }
}